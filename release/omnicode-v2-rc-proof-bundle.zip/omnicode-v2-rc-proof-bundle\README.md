﻿# OmniCode v2 RC Proof Bundle

Release headline:

OmniCode v2 RC: selector-fixed, byte-exact, zero-unknown repo intelligence for AI agents.

Launch-safe benchmark line:

Fresh selector-fixed byte-exact rerun: ten repos, zero errors, 13,041 files accounted, zero unknown files, measured byte reduction 99.525269%, reduction factor 210.65x.

Included docs:

- BENCHMARK_FINAL.md
- METHODOLOGY.md
- ANOMALIES.md
- RESOLUTION_LEDGER_SPEC.md
- CLAIMS_AND_LIMITS.md
- SECURITY.md
- USER_GUIDE.md
- AGENT_INSTALL_UNIVERSAL.md
- AGENT_HOOKS.md
- DOCS_AUDIT.md

Not included as release proof:

- older benchmark methodology drafts
- old coverage-complete v2 narrative docs
- old whitepaper copy
- generated roadmap drafts

Reason: those files contain stale wording, old token framing, or pre-trust-layer tool flow. See DOCS_AUDIT.md.
